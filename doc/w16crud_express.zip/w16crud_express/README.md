## Node.js CRUD with Express.js & MySQL
Tutorial Link: [Node.js Simple CRUD with Express.js and MySQL](https://www.mynotepaper.com/nodejs-simple-crud-with-expressjs-and-mysql.html)

## Output
![node-js-simple-crud-with-express-js-and-mysql-output](https://user-images.githubusercontent.com/13184472/66422500-9a04a600-ea2b-11e9-93b3-0f2cc7c18e3f.gif)

## LICENCE
You can download the project, modify the code and use it anywhere you want without re-posting to your blog. Happy Coding :)

Thank you.